/************************************************************************************** 
 *
 * 		 	Author:  		  Matt Pringle  
 * 			Date updated:	  01-19-2019 
 *          Coding language:  JAVA 
 * 
 * The purpose of this program is to create a subtotal report.  Report will be a subtotal 
 * breaking on major and gender of the fundraisers. There is NO validation at all in this program. 
 * This program will only handle valid data. The input file will be order by major code and the
 * output will be subtotals on major and then a grand total line will be the last to print.   
 *  
 *  Major codes and the literal equivalent listed below.....
 *  
 *	  	01 - COMPUTER SOFTWARE DEVELOPMENT 		02 - DIESEL POWER SYSTEMS TECHNOLOGY
 *		03 - AUTOMOTIVE TECHNOLOGY				04 - LASER / ELECTRO-OPTICS TECHNOLOGY
 * 		05 - ROBOTICS/AUTOMATION TECHNOLOGY		06 - DIGITAL FORENSICS
 * 		07 � MACHINE TECHNOLOGY					08 � GEOSPATIAL TECHNOLOGY
 * 		09 - ADMINISTRATIVE ASSISTANT			10 - ACCOUNTING ASSISTANT
 * 		11 - WELDING TECHNOLOGY					12 � AUTOMOTIVE COLLISION TECHNOLOGY
 * 		13 � AVAIATION PILOT TRAINING
 *
 *	Input file - IHCCFUND.DAT 
 *  Summary Report = subtotal.prt 
 *  
 **************************************************************************************/
import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.time.format.DateTimeFormatter;
import java.time.LocalDate;
import java.text.*;
import java.util.*;

public class SubtotalReport {
	
	// declare global variables
	
//  declaring contribution accumulators
//	01 - COMPUTER SOFTWARE DEVELOPMENT 		02 - DIESEL POWER SYSTEMS TECHNOLOGY
//	 *		03 - AUTOMOTIVE TECHNOLOGY				04 - LASER / ELECTRO-OPTICS TECHNOLOGY
//	 * 		05 - ROBOTICS/AUTOMATION TECHNOLOGY		06 - DIGITAL FORENSICS
//	 * 		07 � MACHINE TECHNOLOGY					08 � GEOSPATIAL TECHNOLOGY
//	 * 		09 - ADMINISTRATIVE ASSISTANT			10 - ACCOUNTING ASSISTANT
//	 * 		11 - WELDING TECHNOLOGY					12 � AUTOMOTIVE COLLISION TECHNOLOGY
//	 * 		13 � AVAIATION PILOT TRAINING
//************************************************************************************
	static double subtotalAccum = 0;
	
	static LocalDate today = LocalDate.now();
	static LocalDate userDate;
	static DateTimeFormatter dtf = DateTimeFormatter.ofPattern("MM/dd/yyyy");
	
	static String iString;			// generic input string
	
	static String iStuID, iGender, iMajor, record, oMajor, oGender, oDonation;
	static String prevMajor = "01";
	static double iDonation;
	static double grandTotal;
	static int stuCtr;
	static int totStu;
	static int majorCtr;
		
	static Scanner donationScanner;	//input device to read from .dat file
	static boolean EOF = false;	
	
	static PrintWriter pw;			// file used for summary.prt output
	static NumberFormat nf;
	
// ********************************************************************
// ************  The start of the programs logic  *********************
// ********************************************************************
	
	public static void main(String[] args) {
		
		init();    
		headings();
		prevMajor = iMajor;
				
		do {if (iMajor.equals(prevMajor)) {
				detailLines();
			}
			else  {
				subtotals();
				detailLines();
				prevMajor = iMajor; }
			readNextRecord();
		} while (!EOF);
		
		subtotals();
		totals();
		
		pw.format("%n");
		pw.format("                                               *** Program has ended successfully ***");
		
		pw.close();
	}
//*********************************************************************************************
// initialize the input file, output file
//*********************************************************************************************	
		
	public static void init() {
									// set scanner to input file 
		try {
			donationScanner = new Scanner(new File("IHCCFUND.DAT"));
			donationScanner.useDelimiter(System.getProperty("line.separator"));
		} 
		catch (FileNotFoundException e1) {
			System.out.println(" * File error * ");
			System.exit(1);
		}
				// set formatter to use US currency format
		nf = NumberFormat.getCurrencyInstance(java.util.Locale.US);
		
				//  declaring output files
		try {
			pw = new PrintWriter(new File ("subtotal.prt"));
		} 
		catch (FileNotFoundException e) {
			System.out.println("Output file error");
		}
	}		
//*********************************************************************************************
// headings
//*********************************************************************************************

	public static void headings() {
		
		pw.format("%10s%30s%45s%n",
			    today.format(dtf), " ", "Indian Hills Advanced Technology Center");
		pw.format("%-48s%36s%n",
	            " ", "Detailed Fundraising Report by Major");
		pw.format("%n");
		pw.format("%14s%7s%n",
			    " ", "Student");
		pw.format("%17s%2s%14s%6s%25s%5s%30s%8s%n",
			    " ", "ID", " ", "Gender", " ", 
			    "Major", " ", "Donation");
		pw.format("%n");
		
		//initial reading of dat.file
		readNextRecord();				
	}
	
//*********************************************************************************************
// format and print detail lines
//*********************************************************************************************
	
	public static void detailLines() {

		subtotalAccum += iDonation;
		stuCtr++;		
		pw.format("%14s%7s%12s%-6s%12s%-35s%13s%8.2f%n", 
				" ", iStuID, " ", oGender, " ",	oMajor, " ", iDonation);
	}
		 	
//*********************************************************************************************
// read the next record and format literals for gender and major
//********************************************************************************************
	
	public static void readNextRecord() {
			
		if (donationScanner.hasNext()) {
			record = donationScanner.next();	
			iStuID = record.substring(0,7);			//file position 1 - 7
			iGender = record.substring(7,8);		//file position 7 - 8
			iMajor = record.substring(8,10);		//file position 8 - 10
			iString = record.substring(10,17);		//file position 10-17 
			iDonation = Double.parseDouble(iString);
			}
		else {
			EOF=true;	//no more records so set eof to true
			}
		
		switch (iGender) {
		case "M":
			oGender = "Male";
			break;
		case "F":
			oGender = "Female";
			}
		
		switch (iMajor) {
		case "01":
			oMajor = "Computer Software Development";
			break;
		case "02":
			oMajor = "Diesel Power Systems Technology";
			break;
		case "03":
			oMajor = "Automotive Technology";
			break;
		case "04":
			oMajor = "Laser / Electro-Optics Technology";
			break;
		case "05":
			oMajor = "Robotics/Automation Technology";
			break;
		case "06":
			oMajor = "Digital Forensics";
			break;
		case "07":
			oMajor = "Machine Technology";
			break;
		case "08":
			oMajor = "Geospatial Technology";
			break;
		case "09":
			oMajor = "Administrative Assistant";
			break;
		case "10":
			oMajor = "Accounting Assistant";
			break;
		case "11":
			oMajor = "Welding Technology";
			break;
		case "12":
			oMajor = "Automotive Collision Technology";
			break;
		case "13":
			oMajor = "Avaiation Pilot Training";
			}
		}
//*********************************************************************************************
// subtotals to be done when major break takes place
//*********************************************************************************************
	
	public static void subtotals() {

		grandTotal += subtotalAccum;
		totStu += stuCtr;
		pw.format("%n");
		switch (prevMajor) {
		case "01":
			pw.format("%20s%35s%5s%4s%5s%18s%7.2f%n",
				    " ", "Computer Software Development", " ", stuCtr, " ", 
				    "Subtotal Donations:  ", subtotalAccum);
			break;
		case "02":
			pw.format("%20s%35s%5s%4s%5s%18s%7.2f%n",
				    " ", "Diesel Power Systems Technology", " ", stuCtr, " ", 
				    "Subtotal Donations:  ", subtotalAccum);
			break;
		case "03":
			pw.format("%20s%35s%5s%4s%5s%18s%7.2f%n",
				    " ", "Automotive Technology", " ", stuCtr, " ", 
				    "Subtotal Donations:  ", subtotalAccum);
			break;
		case "04":
			pw.format("%20s%35s%5s%4s%5s%18s%7.2f%n",
				    " ", "Laser / Electro-Optics Technology", " ", stuCtr, " ", 
				    "Subtotal Donations:  ", subtotalAccum);
			break;
		case "05":
			pw.format("%20s%35s%5s%4s%5s%18s%7.2f%n",
				    " ", "Robotics/Automation Technology", " ", stuCtr, " ", 
				    "Subtotal Donations:  ", subtotalAccum);
			break;
		case "06":
			pw.format("%20s%35s%5s%4s%5s%18s%7.2f%n",
				    " ", "Digital Forensics", " ", stuCtr, " ", 
				    "Subtotal Donations:  ", subtotalAccum);
			break;
		case "07":
			pw.format("%20s%35s%5s%4s%5s%18s%7.2f%n",
				    " ", "Machine Technology", " ", stuCtr, " ", 
				    "Subtotal Donations:  ", subtotalAccum);
			break;
		case "08":
			pw.format("%20s%35s%5s%4s%5s%18s%7.2f%n",
				    " ", "Geospatial Technology", " ", stuCtr, " ", 
				    "Subtotal Donations:  ", subtotalAccum);
			break;
		case "09":
			pw.format("%20s%35s%5s%4s%5s%18s%7.2f%n",
				    " ", "Administrative Assistant", " ", stuCtr, " ", 
				    "Subtotal Donations:  ", subtotalAccum);
			break;
		case "10":
			pw.format("%20s%35s%5s%4s%5s%18s%7.2f%n",
				    " ", "Accounting Assistant", " ", stuCtr, " ", 
				    "Subtotal Donations:  ", subtotalAccum);
			break;
		case "11":
			pw.format("%20s%35s%5s%4s%5s%18s%7.2f%n",
				    " ", "Welding Technology", " ", stuCtr, " ", 
				    "Subtotal Donations:  ", subtotalAccum);
			break;
		case "12":
			pw.format("%20s%35s%5s%4s%5s%18s%7.2f%n",
				    " ", "Automotive Collision Technology", " ", stuCtr, " ", 
				    "Subtotal Donations:  ", subtotalAccum);
			break;
		case "13":
			pw.format("%20s%35s%5s%4s%5s%18s%7.2f%n",
				    " ", "Aviation Pilot Training", " ", stuCtr, " ", 
				    "Subtotal Donations:  ", subtotalAccum);
			}
		
		pw.format("%n");
// zero accums and counters
		subtotalAccum = 0;
		stuCtr = 0;
	}
//*********************************************************************************************
// format and display output and totals
//*********************************************************************************************
	public static void totals() {

		pw.format("%20s%25s%5s%4s%5s%18s%8.2f%n",
				    " ", "Total Number of Students", " ", totStu, " ", 
				    "Total Donations:  ", grandTotal);		
	}
}