/************************************************************************************** 
 *
 * 		 	Author:  		  Matt Pringle  
 * 			Date updated:	  01-19-2019 
 *          Coding language:  JAVA 
 * 
 * The purpose of this program is to create a summary report.  Report will be a summarize 
 * the major and gender of the fundraisers. There is NO validation at all in this program. 
 * This program will only handle valid data. The input file will be order by major code.   
 * The summary report will put in groups the following:
 * 
 *			1)	Male										7)  Female Information Technology  
 *			2)	Female										8)  Male Manufacturing Technology
 *			3)	Information Technology (01,06,08,09,10)		9)  Female Manufacturing Technology
 *			4)	Manufacturing Technology (04,05,07,11)		10) Male Transportation Technology
 *			5)	Transportation Technology (02,03,12,13)		11) Female Transportation Technology
 *			6)	Male Information Technology					12) Overall
 *
 *	Input file - IHCCFUND.DAT 
 *  Summary Report = summary.prt 
 *  
 **************************************************************************************/
import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.time.format.DateTimeFormatter;
import java.time.LocalDate;
import java.text.*;
import java.util.*;

public class SummaryReport {
	
	// declare global variables
	
//  declaring contribution accumulators  
	static double totMenContrib = 0;
	static double totWomenContrib = 0;
	static double itContrib = 0;
	static double mtContrib = 0;
	static double ttContrib = 0;
	static double itMenContrib = 0;
	static double mtMenContrib = 0;
	static double ttMenContrib = 0;
	static double itWomenContrib = 0;
	static double mtWomenContrib = 0;
	static double ttWomenContrib = 0;
	static double totContrib = 0;
	
//  declaring contribution average variables
	static double avgTotMenContrib = 0;
	static double avgTotWomenContrib = 0;
	static double avgItContrib = 0;
	static double avgMtContrib = 0;
	static double avgTtContrib = 0;
	static double avgItMenContrib = 0;
	static double avgMtMenContrib = 0;
	static double avgTtMenContrib = 0;
	static double avgItWomenContrib = 0;
	static double avgMtWomenContrib = 0;
	static double avgTtWomenContrib = 0;
	static double avgTotContrib = 0;
	static double wavgTotMenContrib = 0;
	static double wavgTotWomenContrib = 0;
	static double wavgItContrib = 0;
	static double wavgMtContrib = 0;
	static double wavgTtContrib = 0;
	static double wavgItMenContrib = 0;
	static double wavgMtMenContrib = 0;
	static double wavgTtMenContrib = 0;
	static double wavgItWomenContrib = 0;
	static double wavgMtWomenContrib = 0;
	static double wavgTtWomenContrib = 0;
	static double wavgTotContrib = 0;
	
//  declaring counters 	
	static int totMenCtr = 0;
	static int totWomenCtr = 0;
	static int itCtr = 0;
	static int mtCtr = 0;
	static int ttCtr = 0;
	static int itMenCtr = 0;
	static int mtMenCtr = 0;
	static int ttMenCtr = 0;
	static int itWomenCtr = 0;
	static int mtWomenCtr = 0;
	static int ttWomenCtr = 0;
	static int totCtr = 0;
	
	static LocalDate today = LocalDate.now();
	static LocalDate userDate;
	static DateTimeFormatter dtf = DateTimeFormatter.ofPattern("MM/dd/yyyy");
	
	static String iString;			// generic input string
	
	static String iStuID, iGender, iMajor, record, oMajor, oItContrib, oMtContrib, oTtContrib,
		ototMenContrib, oavgTotMenContrib, ototWomenContrib, oavgTotWomenContrib, ototItContrib, oavgMtContrib,
		ototTtContrib, oavgItContrib, oavgTtContrib, oavgTtMenContrib, oItMenContrib, oItWomenContrib, 
		oTtMenContrib, oTtWomenContrib, oMtMenContrib, oMtWomenContrib, oavgMtMenContrib, oavgItMenContrib, 
		oavgItWomenContrib, oavgTtWomenContrib, oavgMtWomenContrib, ototContrib, oavgTotContrib;
	static double iDonation;
		
	static Scanner donationScanner;	//input device to read from .dat file
	static boolean EOF = false;
	
	static PrintWriter pw;			// file used for summary.prt output
	static NumberFormat nf;
	
// ********************************************************************
// ************  The start of the programs logic  *********************
// ********************************************************************
	
	public static void main(String[] args) {
		
		init();    
		
		while (!EOF ) {
			calcs();
			readNextRecord();
			}  
			
		calcAvgs();
		
		output();
		
		pw.close();
		
		pw.format("     *** Program has ended successfully ***");
	}
//*********************************************************************************************
// initialize the input file, output file and scanner to receive input from user and read 1st rec
//*********************************************************************************************	
		
	public static void init() {
									// set scanner to input file 
		try {
			donationScanner = new Scanner(new File("IHCCFUND.DAT"));
			donationScanner.useDelimiter(System.getProperty("line.separator"));
		} 
		catch (FileNotFoundException e1) {
			System.out.println(" * File error * ");
			System.exit(1);
		}
				// set formatter to use US currency format
		nf = NumberFormat.getCurrencyInstance(java.util.Locale.US);
		
				//  declaring output files
		try {
			pw = new PrintWriter(new File ("summary.prt"));
		} 
		catch (FileNotFoundException e) {
			System.out.println("Output file error");
		}
		
		//initial reading of dat.file
		readNextRecord();
	}		

//*********************************************************************************************
// calculates record count, total contributions (per group), average contribution (per group)
//*********************************************************************************************
		
	public static void calcs() {
		
		totCtr++;
		totContrib += iDonation;
		
		if (iGender.equals("M")) {
			totMenCtr++;
			totMenContrib += iDonation;
			switch(iMajor) {
			case "01":
			case "06":
			case "08":
			case "09":
			case "10": 
				itContrib += iDonation;
				itMenContrib += iDonation;
				itCtr++;
				itMenCtr++;  
				break;
			case "04":
			case "05":
			case "07":
			case "11": 
				mtContrib += iDonation;
				mtMenContrib += iDonation;
				mtCtr++;
				mtMenCtr++;
				break;
			case "02":
			case "03":
			case "12":
			case "13":
				ttContrib += iDonation;
				ttMenContrib += iDonation;
				ttCtr++;
				ttMenCtr++;
				break;
			}
		}
		else {
			totWomenCtr++;
			totWomenContrib += iDonation;
			switch(iMajor) {
			case "01":
			case "06":
			case "08":
			case "09":
			case "10":
				itContrib += iDonation;
				itWomenContrib += iDonation;
				itCtr++;
				itWomenCtr++;
				break;
			case "04":
			case "05":
			case "07":
			case "11":
				mtContrib += iDonation;
				mtWomenContrib += iDonation;
				mtCtr++;
				mtWomenCtr++;
				break;
			case "02":
			case "03":
			case "12":
			case "13":
				ttContrib += iDonation;
				ttWomenContrib += iDonation;
				ttCtr++;
				ttWomenCtr++;
				}
			}
		}
	
//*********************************************************************************************
// read the next record and if last record then indicate End of File and quit
//*********************************************************************************************
	
	public static void readNextRecord() {
			
		if (donationScanner.hasNext()) {
			record = donationScanner.next();	
			iStuID = record.substring(0,7);			//file position 1 - 7
			iGender = record.substring(7,8);		//file position 7 - 8
			iMajor = record.substring(8,10);			//file position 8 - 10
			iString = record.substring(10,17);		//file position 10-17 
			iDonation = Double.parseDouble(iString);
//			System.out.println("Student ID = " + iStuID);
//			System.out.println("Gender = " + iGender);
//			System.out.println("Student Major = " + iMajor);
//			System.out.println("Donation = " + iDonation);
			}
		else {
			EOF=true;	//no more records so set eof to true
			}
		}
//*********************************************************************************************
// calculate averages for final output - check counters to avoid division by zero
//*********************************************************************************************
		
	public static void calcAvgs() {
		
			avgTotMenContrib = totMenContrib / totMenCtr;
			wavgTotMenContrib = avgTotMenContrib * 100.0;	
			wavgTotMenContrib = Math.round(wavgTotMenContrib);
			wavgTotMenContrib = wavgTotMenContrib/100.0;
			avgTotMenContrib = wavgTotMenContrib;
			
			avgItMenContrib = itMenContrib / itMenCtr;
			wavgItMenContrib = avgItMenContrib * 100.0;	
			wavgItMenContrib = Math.round(wavgItMenContrib);
			wavgItMenContrib = wavgItMenContrib/100.0;
			avgItMenContrib = wavgItMenContrib;
			
			avgMtMenContrib = mtMenContrib / mtMenCtr;
			wavgMtMenContrib = avgMtMenContrib * 100.0;	
			wavgMtMenContrib = Math.round(wavgMtMenContrib);
			wavgMtMenContrib = wavgMtMenContrib/100.0;
			avgMtMenContrib = wavgMtMenContrib;
			
			avgTtMenContrib = ttMenContrib / ttMenCtr;
			wavgTtMenContrib = avgTtMenContrib * 100.0;	
			wavgTtMenContrib = Math.round(wavgTtMenContrib);
			wavgTtMenContrib = wavgTtMenContrib/100.0;
			avgTtMenContrib = wavgTtMenContrib;
		
			avgTotWomenContrib = totWomenContrib / totWomenCtr;
			wavgTotWomenContrib = avgTotWomenContrib * 100.0;	
			wavgTotWomenContrib = Math.round(wavgTotWomenContrib);
			wavgTotWomenContrib = wavgTotWomenContrib/100.0;
			avgTotWomenContrib = wavgTotWomenContrib;
			
			avgItWomenContrib = itWomenContrib / itWomenCtr;
			wavgItWomenContrib = avgItWomenContrib * 100.0;	
			wavgItWomenContrib = Math.round(wavgItWomenContrib);
			wavgItWomenContrib = wavgItWomenContrib/100.0;
			avgItWomenContrib = wavgItWomenContrib;
			
			avgMtWomenContrib = mtWomenContrib / mtWomenCtr;
			wavgMtWomenContrib = avgMtWomenContrib * 100.0;	
			wavgMtWomenContrib = Math.round(wavgMtWomenContrib);
			wavgMtWomenContrib = wavgMtWomenContrib/100.0;
			avgMtWomenContrib = wavgMtWomenContrib;
			
			avgTtWomenContrib = ttWomenContrib / ttWomenCtr;
			wavgTtWomenContrib = avgTtWomenContrib * 100.0;	
			wavgTtWomenContrib = Math.round(wavgTtWomenContrib);
			wavgTtWomenContrib = wavgTtWomenContrib/100.0;
			avgTtWomenContrib = wavgTtWomenContrib;
		
			avgItContrib = itContrib / itCtr;
			wavgItContrib = avgItContrib * 100.0;	
			wavgItContrib = Math.round(wavgItContrib);
			wavgItContrib = wavgItContrib/100.0;
			avgItContrib = wavgItContrib;
			
			avgMtContrib = mtContrib / mtCtr;
			wavgMtContrib = avgMtContrib * 100.0;	
			wavgMtContrib = Math.round(wavgMtContrib);
			wavgMtContrib = wavgMtContrib/100.0;
			avgMtContrib = wavgMtContrib;
			
			avgTtContrib = ttContrib / ttCtr;
			wavgTtContrib = avgTtContrib * 100.0;	
			wavgTtContrib = Math.round(wavgTtContrib);
			wavgTtContrib = wavgTtContrib/100.0;
			avgTtContrib = wavgTtContrib;
			
			avgTotContrib = totContrib / totCtr;
			wavgTotContrib = avgTotContrib * 100.0;	
			wavgTotContrib = Math.round(wavgTotContrib);
			wavgTotContrib = wavgTotContrib/100.0;
			avgTotContrib = wavgTotContrib;
	}
//*********************************************************************************************
// format and display output and totals
//*********************************************************************************************
	public static void output() {
		pw.format("%10s%40s%30s%n",
				    today.format(dtf), " ", "Indian Hills Community College");
		pw.format("%-52s%26s%n",
		            " ", "Fundraising Summary Report");
		pw.format("%n");
		
		pw.format("%-84s%29s%n",
				" ", "Total                 Average");
		pw.format("%14s%5s%44s%5s%15s%9s%14s%8s%n",
		      " ", "Group", " ", "Count", " ", "Donations", " ", "Donation");
		pw.format("%n");
		
		ototMenContrib = nf.format(totMenContrib);
		oavgTotMenContrib = nf.format(avgTotMenContrib);
		pw.format("%14s%-32s%12s%10d%12s%12s%13s%9s%n", 
				" ", "Male", " ", totMenCtr, " ", 
				ototMenContrib, " ", oavgTotMenContrib);
		
		ototWomenContrib = nf.format(totWomenContrib);
		oavgTotWomenContrib = nf.format(avgTotWomenContrib);
		pw.format("%14s%-32s%12s%10d%12s%12s%13s%9s%n", 
				" ", "Female", " ", totWomenCtr, " ", 
				ototWomenContrib, " ", oavgTotWomenContrib);
		
		oItContrib = nf.format(itContrib);
		oavgItContrib = nf.format(avgItContrib);
		pw.format("%14s%-32s%12s%10d%12s%12s%13s%9s%n", 
				" ", "Information Technology", " ", itCtr, " ", 
				oItContrib, " ", oavgItContrib);
		
		oMtContrib = nf.format(mtContrib);
		oavgMtContrib = nf.format(avgMtContrib);
		pw.format("%14s%-32s%12s%10d%12s%12s%13s%9s%n", 
				" ", "Manufacting Technology", " ", mtCtr, " ", 
				oMtContrib, " ", oavgMtContrib);
		
		oTtContrib = nf.format(ttContrib);
		oavgTtContrib = nf.format(avgTtContrib);
		pw.format("%14s%-32s%12s%10d%12s%12s%13s%9s%n", 
				" ", "Transportation Technology", " ", ttCtr, " ", 
				oTtContrib, " ", oavgTtContrib);
		
		oItMenContrib = nf.format(itMenContrib);
		oavgItMenContrib = nf.format(avgItMenContrib);
		pw.format("%14s%-32s%12s%10d%12s%12s%13s%9s%n", 
				" ", "Male Information Technology", " ", itMenCtr, " ", 
				oItMenContrib, " ", oavgItMenContrib);
				
		oItWomenContrib = nf.format(itWomenContrib);
		oavgItWomenContrib = nf.format(avgItWomenContrib);
		pw.format("%14s%-32s%12s%10d%12s%12s%13s%9s%n", 
				" ", "Female Information Technology", " ", itWomenCtr, " ", 
				oItWomenContrib, " ", oavgItWomenContrib);
		
		oMtMenContrib = nf.format(mtMenContrib);
		oavgMtMenContrib = nf.format(avgMtMenContrib);
		pw.format("%14s%-32s%12s%10d%12s%12s%13s%9s%n", 
				" ", "Male Manufacturing Technology", " ", mtMenCtr, " ", 
				oMtMenContrib, " ", oavgMtMenContrib);
		
		oMtWomenContrib = nf.format(mtWomenContrib);
		oavgMtWomenContrib = nf.format(avgMtWomenContrib);
		pw.format("%14s%-32s%12s%10d%12s%12s%13s%9s%n", 
				" ", "Female Manufacturing Technology", " ", mtWomenCtr, " ", 
				oMtWomenContrib, " ", oavgMtWomenContrib);
		
		oTtMenContrib = nf.format(ttMenContrib);
		oavgTtMenContrib = nf.format(avgTtMenContrib);
		pw.format("%14s%-32s%12s%10d%12s%12s%13s%9s%n", 
				" ", "Male Transportation Technology", " ", ttMenCtr, " ", 
				oTtMenContrib, " ", oavgTtMenContrib);
		
		oTtWomenContrib = nf.format(ttWomenContrib);
		oavgTtWomenContrib = nf.format(avgTtWomenContrib);
		pw.format("%14s%-32s%12s%10d%12s%12s%13s%9s%n", 
				" ", "Female Transportation Technology", " ", ttWomenCtr, " ", 
				oTtWomenContrib, " ", oavgTtWomenContrib);
		
		ototContrib = nf.format(totContrib);
		oavgTotContrib = nf.format(avgTotContrib);
		pw.format("%14s%-32s%12s%10d%12s%12s%13s%9s%n", 
				" ", "Overall", " ", totCtr, " ", ototContrib, " ", oavgTotContrib);
	}
}